console.log("Prime Numbers");


num = prompt("Enter maximum value");
function primeFactorsTo(max){
    let store = [], i, j,
    prime = [];
    for(i = 2; i<= max; ++i){
        if(!store[i])
        {
            prime.push(i);
            for(j= i<< 1; j<= max; j += i){
                store[j] = true;
            }
        }
    }
    return prime;
}
console.log(primeFactorsTo(num));