console.log("calculator operations");

/*
let sum = function(a,b){
    let result = a+b;
    
}

let substraction = function(a,b){
    let result = a-b;
    
}

let multiply = function(a,b){
    let result = a*b;
    
}

let division = function(a,b){
    let result = a/b;
    
}

let modulus = function(a,b){
    let result = a%b;
    
}

let sqroot = function(){
    let result = sqrt(a,b);
    
}

let avrg = function average() {
    return avrg.reduce((a, b) => (a + b)) / avrg.length;
}
*/
let a,b;
let operation = prompt("Enter operation name in small letters");
let val = prompt("Enter two values with space");
let values = val.split(" ");
switch(operation){
    case 'add':{
        let result =+values[0] + +values[1];
        console.log(result);
        break;
    }
    case 'sub':{
        let result =+values[0] - +values[1];
        console.log(result);
        break;
    }
    case 'multiply':{
        let result =+values[0] * +values[1];
        console.log(result);
        break;
    }
    case 'divide':{
        let result =+values[0] / +values[1];
        console.log(result);
        break;
    }
    case 'modulus':{
        let result =+values[0] % +values[1];
        console.log(result);
        break;
    }
    case 'percent':{
        let result =+values[0] % +values[1];
        console.log(result);
        break;
    }
    case 'root':{
        let result =Math.sqrt(+values[0] + +values[1]);
        console.log(result);
        break;
    }
    default:{
        console.log("Invald operation");
        break;
    }
}


