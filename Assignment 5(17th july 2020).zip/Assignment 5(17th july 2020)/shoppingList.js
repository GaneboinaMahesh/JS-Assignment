console.log("Shopping List");

const shoppingList = ['Fruits', 'Vegetables', 'Pulses'];
console.log(shoppingList);

const shoppingBasket = [...shoppingList, 'Meat', 'Eggs', 'Edible Oil'];
console.log(shoppingBasket);
