console.log("Destructure of Object");

const student= {
    name: "Helsinki",
    age: 30,
    project: {
        diceGame: "Two player Dice Game Using Javascript"
    }
}

const {name,age, project}= student;
console.log(name,age,project);
