console.log("Arrow Function");

function ask(question, yes, no){
    if(confirm(question)){
         yes()
    }
    
    else{
         no();
    }
}
ask(
    "Do you Agree?",
    () => alert("You Agreed."),
    () => alert("You cancelled the Execution.")
);


/* Alternate method
let ask = (question, yes, no) => confirm(question)? yes() : no();
ask(
    "Do you agree",
    () => console.log("You Agreed."),
    () => console.log("You cancelled the Execution.")
);
*/