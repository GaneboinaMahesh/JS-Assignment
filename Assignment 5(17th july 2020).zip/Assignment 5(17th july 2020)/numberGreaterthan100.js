console.log("Number Greater than 100");

//function checkNumber(num){
    let num = Number(prompt("Enter a number"));
    if(num > 100){
        console.log(num, " is Greater than 100");
    }
    else if(num <= 100){
        console.log("Enter a number Greater than 100");
    }
    else{
        console.log("Invald Entry");
    }
/*
checkNumber(101);
checkNumber(57);
checkNumber(99);
checkNumber(199.73);
checkNumber("abc");
*/
/*
let num = Number(prompt("Enter a number"));

num = (num>100)? `${num} is Greater than 100` : `Enter a number Greater than 100`;

console.log(num);

*/
