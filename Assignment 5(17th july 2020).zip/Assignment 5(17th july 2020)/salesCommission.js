console.log("Sales Commission");

let totalSales = parseInt(prompt("Enter Total Sales"));
    
if((totalSales>0) && (totalSales<=5000)){
    let commission = totalSales * 0.02;
    console.log("Total Commission earned is : ", commission);
}
else if((totalSales>5000) && (totalSales<=10000)){
    commission = totalSales * 0.05;
    console.log("Total Commission earned is : ", commission);
}
else if((totalSales>10000) && (totalSales<20000)){
    commission = totalSales * 0.07;
    console.log("Total Commission earned is : ", commission);
}
else if(totalSales>20000){
    commission = totalSales * 0.10;
    console.log("Total Commission earned is : ", commission); 
}
else{
    console.log("No Commission")
}