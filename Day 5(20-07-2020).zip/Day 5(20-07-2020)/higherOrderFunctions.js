console.log("Higher Order Functions");

let numbers = [1,2,3,4,5];
/*const allPositiveNumbers = numbers.every(function(item){
    return item > 0;
});
console.log(allPositiveNumbers);
console.log(numbers);
*/
const array = numbers.map(function(item){
    return item;
});
console.log(array);

const oddNumbers = array.filter(function(item){
    return item % 2 !== 0;
});
console.log(oddNumbers);

const cubes = oddNumbers.map(function(item){
    return Math.pow(item,3);
});
console.log(cubes);


