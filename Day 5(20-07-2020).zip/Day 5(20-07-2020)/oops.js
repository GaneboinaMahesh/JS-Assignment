console.log("oops in javascript");

class user{
    constructor(name, age, email){
        this.name = name;
        this.age = age;
        this.email = email;
        this.luCoins = 0;
        this.courses = [];

    }

    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }

    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }

  
    getDetails(){
        console.log(`Name is ${this.name}, email is ${this.email}`);
        return this;
    }

}

class Moderator extends user{
    constructor(name, age, email, role){
        super(name,age,email);
        this.role = role;
    }

    addCoins(){
        this.luCoins++;
        console.log(`${this.name} has ${this.luCoins} coins`);
        return this;
        }
    
    /*    
    deleteUser(user){
        users = users.filter(u => {
            return u.email != user.email;
        })
    }
    */

    removeCoins(){
        this.luCoins--;
        console.log(`${this.name} has ${this.luCoins} coins`);
        return this;
    }
}

class Admin extends Moderator{
    addCourse(user,course){
        user.courses.push(course);
        console.log(user);
    }

    deleteCourse(user,course){
        courses = courses.filter(course =>{
            return course.courses != user.course
        })
    }
}

let user1 = new user('lal',25,'lal@gmail.com')
let user2 = new user('kumar',24,'k@gmai.com')
let mod = new Moderator('sai',24,'sai@gmail.com','Moderator');
let admin = new Admin('vayu',30,'vayu@gmail.com');
let users = [user1,user2,mod,admin];

users.forEach(element => {
    console.log(element);
});
admin.addCourse(user1,'Javascript');
admin.addCourse(user1,'Python');
admin.addCourse(user2, 'Java');
admin.addCourse(user2, 'Blockchain');
admin.addCourse(mod, 'Python');
admin.addCourse(mod, 'Javascript');
mod.addCoins(user2);
mod.addCoins(user1);
