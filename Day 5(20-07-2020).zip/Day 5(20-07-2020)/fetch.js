console.log("Fetch Api");

async function todo(){
    const val = new Promise((resolve,reject)=>{
        setTimeout(() => {
            const error =false;
            if(!error){
                resolve(
                    fetch("https://jsonplaceholder.typicode.com/todos")
                );
            }
            else{
                reject("error occured");
            }
        },0);
    })
    await val.then(response=>response.json())
    .then(date=>console.log(date))
    .catch(error=>console.log(error));
}
todo();