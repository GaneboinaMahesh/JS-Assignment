let colors = ['lightblue','red', 'limegreen', 'magenta', 'purple', 'green', 'gray', 'hotpink'];
let colorIndex = 0;

function changeColor(){
document.bgColor = colors[colorIndex];
    colorIndex = (colorIndex + 1) % colors.length;
    document.body.style.backgroundColor = colorIndex;
    setTimeout(changeColor, 3000);
}
changeColor();