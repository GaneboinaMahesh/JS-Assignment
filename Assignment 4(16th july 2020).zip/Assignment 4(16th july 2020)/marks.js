console.log("Hello Javascript");
let marks=55;

if((marks>=0) && (marks<35)){
    console.log(`Your Marks are ${marks} and your Grade is F`);
}
else if((marks>=35) && (marks<50)){
    console.log(`Your Marks are ${marks} and your Grade is E`);
}
else if((marks>=50) && (marks<60)){
    console.log(`Your Marks are ${marks} and your Grade is D`);
}
else if((marks>=60) && (marks<70)){
    console.log(`Your Marks are ${marks} and your Grade is C`);
}
else if((marks>=70) && (marks<75)){
    console.log(`Your Marks are ${marks} and your Grade is B`);
}
else if((marks>=75) && (marks<85)){
    console.log(`Your Marks are ${marks} and your Grade is A`);
}
else if((marks>=85) && (marks<95)){
    console.log(`Your Marks are ${marks} and your Grade is A+`);
}
else if((marks>=95) && (marks<100)){
    console.log(`Your Marks are ${marks} and your Grade is A++`);
}
else{
    console.log(`Invalid Marks`);
}

//================= using Switch case=============

let marks1 = 76;
switch(true){
    case ((marks1>=0) && (marks1<35)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is F`);
    }
    break;
    case ((marks1>=35) && (marks1<50)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is E`);
    }
    break;
    case ((marks1>=50) && (marks1<60)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is D`);
    }
    break;
    case ((marks1>=60) && (marks1<70)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is C`);
    }
    break;
    case ((marks1>=70) && (marks1<75)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is B`);
    }
    break;
    case ((marks1>=75) && (marks1<85)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is A`);
    }
    break;
    case ((marks1>=85) && (marks1<95)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is A+`);
    }
    break;
    case ((marks1>=95) && (marks1<100)):
    {
        console.log(`Your Marks are ${marks1} and your Grade is A++`);
    }
    break;
    default:
        {
        console.log(`Invalid Marks`);
    }
}

