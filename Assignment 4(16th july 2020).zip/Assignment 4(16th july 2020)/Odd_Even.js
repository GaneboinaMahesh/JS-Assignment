console.log("Hello Javascript");
let num, result;
function isOdd(num){
    if(num % 2 == 0){
        result = "The number entered is " + num + " and the number is Even";
    }
    else{
        result = "The number entered is " + num + " and the number is Odd";
    }
}
isOdd(4);
console.log(result);
isOdd(7);
console.log(result);

//======using trenary==============

let num1,result1;
function isEven(num1){
    result1= (num1 % 2 ==0) ? "The number entered is "+ num1 + " and the number is Even" : "The number entered is " + num1 + " and the number is Odd";

}
isEven(17);
console.log(result1);


