console.log("Hello Javascript");

let os_details = prompt("Enter the details of os");
let val = os_details.split(" ");
console.log(`The os name is ${val[0]} and version is ${val[1]}`);
